package org.iesvelazquez.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Practica09SeguridadApplication {

	public static void main(String[] args) {
		SpringApplication.run(Practica09SeguridadApplication.class, args);
	}

}