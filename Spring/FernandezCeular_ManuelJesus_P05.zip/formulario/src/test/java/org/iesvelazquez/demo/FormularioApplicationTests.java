package org.iesvelazquez.demo;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormularioApplicationTests {

	@Test
	void contextLoads() {
	}

}
