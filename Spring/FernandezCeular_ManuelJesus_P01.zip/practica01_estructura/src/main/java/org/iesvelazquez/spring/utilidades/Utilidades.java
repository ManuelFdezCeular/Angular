package org.iesvelazquez.spring.utilidades;

public class Utilidades {

}
