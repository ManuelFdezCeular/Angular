package org.iesvelazquez.spring.seguridad;

public class Seguridad {

}
