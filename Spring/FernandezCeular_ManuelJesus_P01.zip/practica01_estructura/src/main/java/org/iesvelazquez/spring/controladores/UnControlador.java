package org.iesvelazquez.spring.controladores;

public class UnControlador {

}
