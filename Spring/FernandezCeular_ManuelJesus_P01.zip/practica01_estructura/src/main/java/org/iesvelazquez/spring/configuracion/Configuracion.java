package org.iesvelazquez.spring.configuracion;

public class Configuracion {

}
