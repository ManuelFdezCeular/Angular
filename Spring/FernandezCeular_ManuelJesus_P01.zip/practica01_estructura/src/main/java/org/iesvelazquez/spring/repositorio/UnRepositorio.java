package org.iesvelazquez.spring.repositorio;

public interface UnRepositorio {

}
