package org.iesvelazquez.spring.entidades;

public class UnaEntidad {

}
