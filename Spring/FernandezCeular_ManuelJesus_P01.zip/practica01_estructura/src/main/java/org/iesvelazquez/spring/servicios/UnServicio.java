package org.iesvelazquez.spring.servicios;

public class UnServicio {

}
