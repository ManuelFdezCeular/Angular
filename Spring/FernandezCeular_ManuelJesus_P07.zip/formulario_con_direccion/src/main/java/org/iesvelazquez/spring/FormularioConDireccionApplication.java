package org.iesvelazquez.spring;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FormularioConDireccionApplication {

	public static void main(String[] args) {
		SpringApplication.run(FormularioConDireccionApplication.class, args);
	}

}
