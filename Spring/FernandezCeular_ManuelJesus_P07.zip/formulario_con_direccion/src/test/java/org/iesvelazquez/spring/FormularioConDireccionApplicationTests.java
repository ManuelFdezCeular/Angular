package org.iesvelazquez.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FormularioConDireccionApplicationTests {

	@Test
	void contextLoads() {
	}

}
